// ============================================================
// FISH TYCOON 2 — TANK VIEW (Phase 11: Pseudo-3D Visual Overhaul)
// ============================================================

import React, { useEffect, useRef, useState, useMemo } from 'react';
import FishSprite from './FishSprite.jsx';
import { getDecorById, getThemeById } from '../data/decorations.js';
import { REAL_SPECIES_MAP } from '../data/realSpecies.js';

const SWIM_SPEED  = 0.007;
const BOB_AMP     = 0.025;
const BOB_FREQ    = 0.018;
const TURN_CHANCE = 0.0018;

// ── Per-species behavior profile defaults ────────────────────
// behaviorProfile fields (all optional — falls back to constants above):
//   swimSpeed       : multiplier applied to SWIM_SPEED  (default 1.0)
//   turnChance      : overrides TURN_CHANCE
//   bobAmplitude    : overrides BOB_AMP
//   preferredYRange : [minY, maxY] as % — fish drifts toward this band
//   idleProbability : chance per idleTimer reset to go idle (0–1)
//   dartiness       : 0–1; on turn, chance to do a sudden speed burst
function getBehaviorProfile(fish) {
  if (fish?.species?.visualType === 'species' && fish.species.key) {
    return REAL_SPECIES_MAP[fish.species.key]?.behaviorProfile || null;
  }
  return null;
}

const DEPTH_LAYERS = [
  { scale: 0.62, opacity: 0.52, z: 7,  blur: 0.7 },
  { scale: 1.00, opacity: 0.85, z: 10, blur: 0   },
  { scale: 1.22, opacity: 1.00, z: 13, blur: 0   },
];

function getDayPhase() {
  const h = new Date().getHours() + new Date().getMinutes() / 60;
  if (h >= 5  && h < 7)  return { phase: 'dawn',    label: '🌅 Dawn'    };
  if (h >= 7  && h < 17) return { phase: 'day',     label: '☀️ Day'     };
  if (h >= 17 && h < 20) return { phase: 'dusk',    label: '🌇 Dusk'    };
  if (h >= 20 && h < 22) return { phase: 'evening', label: '🌆 Evening'  };
  return                         { phase: 'night',   label: '🌙 Night'   };
}

const DAY_PHASE_STYLES = {
  dawn:    { overlay: 'rgba(255,150, 60,0.18)', rayOpacity: 0.55, starCount: 0  },
  day:     { overlay: 'rgba(180,230,255,0.06)', rayOpacity: 0.90, starCount: 0  },
  dusk:    { overlay: 'rgba(220, 80, 20,0.22)', rayOpacity: 0.45, starCount: 0  },
  evening: { overlay: 'rgba( 60, 20,100,0.35)', rayOpacity: 0.15, starCount: 5  },
  night:   { overlay: 'rgba( 10, 10, 50,0.52)', rayOpacity: 0.04, starCount: 12 },
};

const STARS = Array.from({ length: 12 }, (_, i) => ({
  x: ((i * 73 + 17) % 90) + 3,
  y: ((i * 41 + 11) % 22) + 2,
  r: ((i * 7)  % 3) * 0.4 + 0.6,
  delay: (i * 0.3) % 2,
}));

const CORNER_BOLTS = [
  { corner: 'tl', style: { top: 7, left: 7 } },
  { corner: 'tr', style: { top: 7, right: 7 } },
  { corner: 'bl', style: { bottom: 7, left: 7 } },
  { corner: 'br', style: { bottom: 7, right: 7 } },
];

export default function TankView({ fish, selectedFishId, onSelectFish, waterQuality, tank, listedFishIds = [] }) {
  // Keep a ref so the animation loop (which has no deps) can read behavior profiles
  const fishMapRef = useRef({});

  // Memoize fishMap — only rebuild when fish ids change, not every render
  const fishIds = fish.map(f => f.id).join(',');
  fishMapRef.current = useMemo(
    () => Object.fromEntries(fish.map(f => [f.id, f])),
    [fishIds] // eslint-disable-line react-hooks/exhaustive-deps
  );

  // ── Positions live in a ref — the animation loop mutates it directly.
  // A lightweight frame counter triggers React re-renders without ever
  // copying the entire positions object via setState each frame.
  const posRef  = useRef({});
  const [, setFrame] = useState(0);

  // Initialise positions for fish that don't have one yet
  const initPos = (f) => {
    const bp = getBehaviorProfile(f);
    const [minY, maxY] = bp?.preferredYRange ?? [20, 75];
    return {
      x: f.x ?? (10 + Math.random() * 80),
      y: f.y ?? (minY + Math.random() * (maxY - minY)),
      vx: (Math.random() > 0.5 ? 1 : -1) * (0.05 + Math.random() * 0.1),
      vy: 0,
      flipped: Math.random() > 0.5,
      phase: Math.random() * Math.PI * 2,
      depthLayer: Math.floor(Math.random() * 3),
      tilt: 0,
      isIdle: false,
      idleTimer: Math.floor(Math.random() * 200),
    };
  };

  // Seed initial positions once
  if (Object.keys(posRef.current).length === 0 && fish.length > 0) {
    for (const f of fish) posRef.current[f.id] = initPos(f);
  }

  // Sync posRef when fish list changes (add/remove)
  useEffect(() => {
    const pos = posRef.current;
    // Add new fish
    for (const f of fish) {
      if (!pos[f.id]) pos[f.id] = initPos(f);
    }
    // Remove gone fish
    const ids = new Set(fish.map(f => f.id));
    for (const id of Object.keys(pos)) {
      if (!ids.has(id)) delete pos[id];
    }
  }, [fishIds]); // eslint-disable-line react-hooks/exhaustive-deps

  // Convenience alias for reading positions in render (ref value, not state)
  const positions = posRef.current;

  const [dayPhase, setDayPhase] = useState(getDayPhase);
  const [hoveredFishId, setHoveredFishId] = useState(null);
  const tickRef = useRef(0);

  useEffect(() => {
    const t = setInterval(() => setDayPhase(getDayPhase()), 60_000);
    return () => clearInterval(t);
  }, []);

  useEffect(() => {
    let frameId;
    const animate = () => {
      tickRef.current++;
      const t = tickRef.current;
      const pos = posRef.current;

      for (const id of Object.keys(pos)) {
        const p = pos[id];
        let { x, y, vx, vy, phase, flipped, depthLayer, tilt, isIdle, idleTimer } = p;

          // ── Resolve per-species behavior profile ──────────────
          const fishObj = fishMapRef.current[id];
          const bp = fishObj ? getBehaviorProfile(fishObj) : null;
          const swimSpeed    = bp ? SWIM_SPEED * bp.swimSpeed       : SWIM_SPEED;
          const bobAmp       = bp ? bp.bobAmplitude                 : BOB_AMP;
          const turnChance   = bp ? bp.turnChance                   : TURN_CHANCE;
          const idleProb     = bp ? bp.idleProbability              : 0.12;
          const dartiness    = bp ? bp.dartiness                    : 0;
          const [prefYMin, prefYMax] = bp?.preferredYRange ?? [8, 80];

          idleTimer = (idleTimer || 0) - 1;
          if (idleTimer <= 0) {
            isIdle = Math.random() < idleProb;
            idleTimer = 80 + Math.floor(Math.random() * 260);
          }

          if (!isIdle) {
            x += vx * swimSpeed * 60;
            y += Math.sin(phase + t * BOB_FREQ) * bobAmp;
            const targetTilt = Math.max(-11, Math.min(11, vx * 16));
            tilt = tilt + (targetTilt - tilt) * 0.05;

            // Gentle drift toward preferred Y band
            if (bp?.preferredYRange) {
              const midY = (prefYMin + prefYMax) / 2;
              vy += (midY - y) * 0.00008;
              vy *= 0.97;
              y += vy;
            }
          } else {
            y += Math.sin(phase + t * BOB_FREQ * 0.35) * bobAmp * 0.45;
            tilt = tilt * 0.94;
          }

          if (x > 90) { vx = -Math.abs(vx) * (0.9 + Math.random() * 0.2); flipped = true;  x = 90; }
          if (x < 5)  { vx =  Math.abs(vx) * (0.9 + Math.random() * 0.2); flipped = false; x = 5;  }
          if (y > prefYMax) { vy -= 0.01; y = Math.min(y, prefYMax + 2); }
          if (y < prefYMin) { vy += 0.01; y = Math.max(y, prefYMin - 2); }
          if (y > 82) { y = 82; vy = -Math.abs(vy); }
          if (y < 6)  { y = 6;  vy =  Math.abs(vy); }

          if (Math.random() < turnChance) {
            const dart = dartiness > 0 && Math.random() < dartiness;
            const speed = dart ? 0.12 + Math.random() * 0.14 : 0.06 + Math.random() * 0.12;
            vx = (Math.random() - 0.5) * speed;
            vy = (Math.random() - 0.5) * 0.03;
            if (Math.abs(vx) < 0.02) vx = 0.05;
            flipped = vx < 0;
          }

        // Mutate in place — no object spread, no setState
        p.x = x; p.y = y; p.vx = vx; p.vy = vy;
        p.flipped = flipped; p.tilt = tilt;
        p.isIdle = isIdle; p.idleTimer = idleTimer;
      }

      // Trigger a re-render by incrementing a cheap counter
      setFrame(f => f + 1);
      frameId = requestAnimationFrame(animate);
    };
    frameId = requestAnimationFrame(animate);
    return () => cancelAnimationFrame(frameId);
  }, []);

  // wq must be declared at component scope — it is used both in the waterBg memo
  // and directly in JSX (dirty-water overlay). Scoping it inside useMemo would make
  // it invisible to the render return, causing a ReferenceError when wq < 40.
  const wq = waterQuality;
  const waterBg = useMemo(() => {
    const theme = getThemeById(tank?.themes?.active || 'tropical');
    const stops = theme.waterGradient;
    // Blend wq degradation: as quality drops the water shifts murky brown
    const wqFactor = wq / 100; // 1 = pristine, 0 = filthy
    const murkR = Math.round((1 - wqFactor) * 60);
    const murkG = Math.round((1 - wqFactor) * 18);
    const murkB = Math.round(-(1 - wqFactor) * 40);
    const blend = (hex, opacity) => {
      const r = parseInt(hex.slice(1,3),16);
      const g = parseInt(hex.slice(3,5),16);
      const b = parseInt(hex.slice(5,7),16);
      const nr = Math.min(255, Math.max(0, r + murkR));
      const ng = Math.min(255, Math.max(0, g + murkG));
      const nb = Math.min(255, Math.max(0, b + murkB));
      return `rgba(${nr},${ng},${nb},${opacity})`;
    };
    const gradStops = stops.map(s => `${blend(s.color, s.opacity)} ${s.offset}`).join(', ');
    return `linear-gradient(to bottom, ${gradStops})`;
  }, [wq, tank?.themes?.active]);
  const ps = DAY_PHASE_STYLES[dayPhase.phase];

  const sortedFish = useMemo(() => [...fish].sort((a, b) => {
    const la = posRef.current[a.id]?.depthLayer ?? 1;
    const lb = posRef.current[b.id]?.depthLayer ?? 1;
    return la - lb;
  }), [fishIds]); // depth layers are set at spawn and don't change

  return (
    <div className="tank-wrapper">
      <div className="day-phase-badge">{dayPhase.label}</div>

      {/* ── Alert indicator strip (item 11) ── */}
      {(() => {
        const alerts = [];
        const sickFish   = fish.filter(f => f.disease || f.health < 30);
        const hungryFish = fish.filter(f => f.hunger > 80);
        const foodLow    = (tank?.supplies?.food ?? 10) < 3;
        const wqLow      = (waterQuality ?? 100) < 40;
        if (sickFish.length > 0)   alerts.push({ key: 'sick',   icon: '🦠', label: `${sickFish.length} sick`, cls: 'alert-pulse--red'   });
        if (hungryFish.length > 0) alerts.push({ key: 'hungry', icon: '🍽️', label: `${hungryFish.length} hungry`, cls: 'alert-pulse--orange' });
        if (foodLow)               alerts.push({ key: 'food',   icon: '🍤', label: 'Low food',  cls: 'alert-pulse--orange' });
        if (wqLow)                 alerts.push({ key: 'wq',     icon: '💧', label: 'Bad water', cls: 'alert-pulse--red'   });
        if (alerts.length === 0) return null;
        return (
          <div className="tank-alert-strip">
            {alerts.map(a => (
              <div key={a.key} className={`tank-alert-badge ${a.cls}`}>
                <span>{a.icon}</span>
                <span className="tank-alert-label">{a.label}</span>
              </div>
            ))}
          </div>
        );
      })()}

      {/* ── Step 4: Glass Tank Shell with corner bolts ── */}
      <div className="tank-glass-shell">
        {CORNER_BOLTS.map(({ corner, style }) => (
          <div key={corner} className={`tank-bolt tank-bolt-${corner}`} style={style}/>
        ))}
        {/* Corner glints — tiny SVG arc highlights at each bolt position */}
        {CORNER_BOLTS.map(({ corner, style }) => {
          // Arc sweep direction varies by corner to catch the light naturally
          const isRight  = corner === 'tr' || corner === 'br';
          const isBottom = corner === 'bl' || corner === 'br';
          const cx = 6, cy = 6;
          // 45° arc tangent point offsets
          const dx = isRight  ?  4 : -4;
          const dy = isBottom ?  4 : -4;
          const sweep = (isRight !== isBottom) ? 1 : 0;
          return (
            <svg
              key={`glint-${corner}`}
              className={`tank-corner-glint tank-corner-glint-${corner}`}
              style={{ ...style, position: 'absolute', width: 16, height: 16, pointerEvents: 'none' }}
              viewBox="0 0 16 16"
              overflow="visible">
              <path
                d={`M${cx + dx},${cy} A6,6,45,0,${sweep},${cx},${cy + dy}`}
                stroke="rgba(255,255,255,0.55)"
                strokeWidth="1.4"
                fill="none"
                strokeLinecap="round"
              />
            </svg>
          );
        })}
        <div className="tank-bevel-top"/>
        <div className="tank-bevel-bottom"/>
        <div className="tank-bevel-left"/>
        <div className="tank-bevel-right"/>
        <div className="tank-glass-shimmer"/>
      </div>

      <div className="tank" style={{ background: waterBg }}>

        <div className="tank-depth-far"/>
        <div className="tank-depth-mid"/>
        <div className="tank-depth-vignette"/>
        <div className="tank-depth-bottom"/>
        <div className="tank-depth-column"/>

        {/* Light rays — expanded to 8 */}
        <div className="light-rays" style={{ opacity: ps.rayOpacity }}>
          {[0,1,2,3,4,5,6,7].map(i => <div key={i} className={`ray ray-${i}`}/>)}
        </div>

        {/* Surface ripples */}
        <div className="surface-ripple"/>
        <div className="surface-ripple surface-ripple-2"/>
        <div className="surface-ripple surface-ripple-3"/>
        <div className="surface-shimmer"/>

        {/* Caustics — 4 staggered layers */}
        <div className="caustic-layer caustic-a"/>
        <div className="caustic-layer caustic-b"/>
        <div className="caustic-layer caustic-c"/>
        <div className="caustic-layer caustic-d"/>

        {/* Ambient mid-water particles */}
        <div className="particles">
          {[0,1,2,3,4,5,6,7,8,9,10,11].map(i =>
            <div key={i} className={`particle particle-${i}`}/>
          )}
        </div>

        {ps.starCount > 0 && (
          <svg className="night-stars" viewBox="0 0 100 30" preserveAspectRatio="none">
            {STARS.slice(0, ps.starCount).map((s, i) => (
              <circle key={i} cx={s.x} cy={s.y} r={s.r} fill="white" opacity="0.65"
                      className="star-twinkle" style={{ animationDelay: `${s.delay}s` }}/>
            ))}
          </svg>
        )}

        {/* Background SVG (far parallax layer) — driven by active tank theme */}
        <svg className="tank-bg-svg" viewBox="0 0 800 400" preserveAspectRatio="xMidYMax slice">
          {(dayPhase.phase === 'night' || dayPhase.phase === 'evening')
            ? <circle cx="700" cy="40" r="22" fill="rgba(255,245,200,0.18)" />
            : dayPhase.phase === 'day'
              ? <circle cx="700" cy="35" r="28" fill="rgba(255,240,150,0.12)" />
              : <ellipse cx="700" cy="40" rx="30" ry="18" fill="rgba(255,160,60,0.14)" />
          }
          {/* Theme scenery layer */}
          <g dangerouslySetInnerHTML={{ __html: getThemeById(tank?.themes?.active || 'tropical').bgSvgFn() }} />
          {/* Layered sand/substrate gradient strip */}
          <defs>
            <linearGradient id="sandSubstrateGrad" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%"   stopColor="#c8a862" stopOpacity="0.00"/>
              <stop offset="18%"  stopColor="#b89050" stopOpacity="0.18"/>
              <stop offset="42%"  stopColor="#a07838" stopOpacity="0.32"/>
              <stop offset="68%"  stopColor="#886030" stopOpacity="0.50"/>
              <stop offset="85%"  stopColor="#6a4420" stopOpacity="0.70"/>
              <stop offset="100%" stopColor="#3c2408" stopOpacity="0.88"/>
            </linearGradient>
          </defs>
          <rect x="0" y="330" width="800" height="70" fill="url(#sandSubstrateGrad)"/>
        </svg>

        {/* Foreground SVG */}
        <svg className="tank-fg-svg" viewBox="0 0 800 400" preserveAspectRatio="xMidYMax slice">
          {/* Step 2: Sandy bottom with 3D bump shading */}
          <ellipse cx="400" cy="432" rx="490" ry="62" fill="#6a4820" opacity="0.45"/>
          <ellipse cx="400" cy="422" rx="465" ry="55" fill="#7a5828"/>
          <ellipse cx="400" cy="416" rx="452" ry="46" fill="#8a6830"/>
          <ellipse cx="400" cy="411" rx="440" ry="38" fill="#9a7840"/>
          <ellipse cx="400" cy="406" rx="428" ry="28" fill="#aa8848"/>
          <ellipse cx="400" cy="402" rx="415" ry="20" fill="#be9a58"/>
          {/* Sandy top highlight — 3D bump from above */}
          <ellipse cx="370" cy="400" rx="290" ry="12" fill="#d0ac68" opacity="0.50"/>
          <ellipse cx="330" cy="399" rx="170" ry="7"  fill="#deba76" opacity="0.28"/>
          {/* Sand ripples */}
          {[55,118,182,248,315,385,455,525,595,658,718].map((x,i) => (
            <ellipse key={i} cx={x+(i%3)*4} cy={406+(i%4)*2} rx={9+i%7} ry={3+(i%3)*0.7}
              fill={['#b09050','#c09860','#cfa060','#9e7c38','#a88040'][i%5]} opacity="0.70"/>
          ))}
          {Array.from({length:16},(_, i)=>(
            <circle key={i} cx={48+i*47+(i%3)*6} cy={405+(i%4)*3}
              r={0.8+(i%3)*0.5}
              fill={['#ba9052','#cca858','#c29655'][i%3]} opacity="0.48"/>
          ))}
          <g transform="translate(80,320)">
            <ellipse cx="0" cy="60" rx="32" ry="22" fill="#c06840"/>
            <ellipse cx="0" cy="55" rx="28" ry="18" fill="#d07848"/>
            {[[-12,0],[0,-8],[12,0],[0,8],[-8,-4],[8,-4]].map(([dx,dy],i)=>(
              <path key={i} d={`M${dx-6},${55+dy} Q${dx},${50+dy} ${dx+6},${55+dy}`}
                    stroke="#b05830" strokeWidth="1.5" fill="none" opacity="0.6"/>
            ))}
            <path d="M-40,70 C-45,40 -35,20 -38,0" stroke="#e08040" strokeWidth="7" fill="none" strokeLinecap="round"/>
            <path d="M-40,70 C-30,35 -20,18 -22,2" stroke="#d07030" strokeWidth="7" fill="none" strokeLinecap="round"/>
            <path d="M-40,70 C-50,30 -55,12 -52,-5" stroke="#e09050" strokeWidth="6" fill="none" strokeLinecap="round"/>
            <circle cx="-38" cy="0"  r="5" fill="#ff9060"/>
            <circle cx="-22" cy="2"  r="5" fill="#ff8050"/>
            <circle cx="-52" cy="-5" r="4" fill="#ffa070"/>
            <circle cx="40" cy="62" r="18" fill="#e05050"/>
            <circle cx="40" cy="58" r="14" fill="#f06060"/>
            {[0,45,90,135,180,225,270,315].map((deg,i)=>(
              <circle key={i} cx={40+12*Math.cos(deg*Math.PI/180)} cy={58+12*Math.sin(deg*Math.PI/180)}
                      r="3" fill="#d04040" opacity="0.7"/>
            ))}
          </g>
          <g transform="translate(390,350)">
            <ellipse cx="0" cy="40" rx="22" ry="12" fill="#c05080"/>
            {[-25,-16,-8,0,8,16,25].map((dx,i) => (
              <g key={i}>
                <path d={`M${dx},42 C${dx+(i%2===0?-5:5)},20 ${dx+(i%2===0?3:-3)},5 ${dx},0`}
                      stroke="#e060a0" strokeWidth="3.5" fill="none" strokeLinecap="round"
                      style={{transformOrigin:`${dx}px 42px`}} className="anemone-tentacle"/>
                <circle cx={dx} cy={0} r="4" fill="#ff80c0" opacity="0.9"/>
              </g>
            ))}
          </g>
          <g transform="translate(660,0)">
            {[0,22,44].map((x,i) => (
              <path key={i} d={`M${x+10},400 C${x+20},340 ${x},280 ${x+25},210 C${x+40},155 ${x+15},120 ${x+30},70`}
                    stroke={['#2d8050','#359060','#28704a'][i]} strokeWidth={8-i*2} fill="none" strokeLinecap="round"
                    className="kelp-sway" style={{animationDelay:`${i*0.6}s`}}/>
            ))}
            <path d="M100,400 L100,280" stroke="#c87840" strokeWidth="5" strokeLinecap="round"/>
            {[280,300,320,340,360,380].map((y,i) => (
              <path key={i} d={`M100,${y} Q${100+30*(i%2===0?1:-1)},${y-15} ${100+55*(i%2===0?1:-1)},${y}`}
                    stroke="#d08040" strokeWidth="2.5" fill="none" opacity="0.8"/>
            ))}
          </g>
          <ellipse cx="250" cy="400" rx="28" ry="16" fill="#506070"/>
          <ellipse cx="255" cy="396" rx="24" ry="12" fill="#607080"/>
          <ellipse cx="248" cy="393" rx="11"  ry="4"  fill="#788898" opacity="0.38"/>
          <ellipse cx="500" cy="402" rx="20" ry="12" fill="#485868"/>
          <ellipse cx="505" cy="398" rx="16" ry="9"  fill="#586878"/>
          <ellipse cx="500" cy="395" rx="8"  ry="3.5" fill="#6a7a8a" opacity="0.38"/>
          <circle cx="82"  cy="310" r="3"   fill="none" stroke="rgba(255,255,255,0.4)" strokeWidth="1" className="deco-bubble deco-b1"/>
          <circle cx="390" cy="340" r="2.5" fill="none" stroke="rgba(255,255,255,0.35)" strokeWidth="1" className="deco-bubble deco-b2"/>
          <circle cx="672" cy="370" r="2"   fill="none" stroke="rgba(255,255,255,0.3)" strokeWidth="1" className="deco-bubble deco-b3"/>
          {(() => {
            const activeTheme = getThemeById(tank?.themes?.active || 'tropical');
            const substrateDecor = activeTheme.substrateId ? getDecorById(activeTheme.substrateId) : null;
            if (!substrateDecor) return null;
            // Tile three instances across the floor for full coverage at natural scale
            const tiles = [
              { x: 140, y: 405, s: 2.8 },
              { x: 400, y: 406, s: 3.0 },
              { x: 660, y: 405, s: 2.8 },
            ];
            return (
              <g key="theme-substrate" dangerouslySetInnerHTML={{
                __html: tiles.map(t => substrateDecor.svgFn(t.x, t.y, t.s)).join('')
              }}/>
            );
          })()}
          {(tank?.decorations?.placed || []).map(item => {
            const decor = getDecorById(item.type);
            if (!decor) return null;
            return (
              <g key={item.instanceId}
                 dangerouslySetInnerHTML={{ __html: decor.svgFn(item.x, item.y, item.scale) }}
              />
            );
          })}
        </svg>

        <div className="bubbles">
          {/* Large wobbling bubbles */}
          {[0,1,2,3].map(i => <div key={`lg-${i}`} className={`bubble bubble-lg bubble-lg-${i}`}/>)}
          {/* Mid bubbles */}
          {[0,1,2,3,4].map(i => <div key={`md-${i}`} className={`bubble bubble-md bubble-md-${i}`}/>)}
          {/* Micro bubbles */}
          {[0,1,2,3,4,5,6].map(i => <div key={`sm-${i}`} className={`bubble bubble-sm bubble-sm-${i}`}/>)}
          {/* Cluster bursts */}
          {[0,1].map(i => <div key={`cl-${i}`} className={`bubble bubble-cluster bubble-cl-${i}`}/>)}
        </div>

        <div className="day-night-overlay" style={{ background: ps.overlay }}/>

        {/* Step 2 & 6: Fish rendered sorted by depth, with tilt + animation */}
        {sortedFish.map(f => {
          const pos = positions[f.id] || { x: f.x??50, y: f.y??40, flipped: false, depthLayer: 1, tilt: 0, isIdle: false };
          const isSelected = f.id === selectedFishId;
          const layer = DEPTH_LAYERS[pos.depthLayer ?? 1];
          const baseSize = f.phenotype?.size === 'Giant' ? 76 : f.stage === 'egg' ? 36 : 54;
          const spriteSize = Math.round(baseSize * layer.scale);
          const tiltAngle = pos.flipped ? -(pos.tilt || 0) : (pos.tilt || 0);
          const animClass = pos.isIdle ? 'fish-idle' : 'fish-swimming';
          const depthLayer = pos.depthLayer ?? 1;
          // Build depth filter inline so it overrides nothing and composes cleanly
          let depthFilter = '';
          if (depthLayer === 0) depthFilter = 'saturate(0.72) brightness(0.88) blur(1.2px) ';
          else if (layer.blur > 0) depthFilter = `blur(${layer.blur}px) `;
          const glowStr = isSelected ? 'drop-shadow(0 0 8px rgba(240,192,64,0.6))' : '';
          const isHovered = f.id === hoveredFishId;
          const healthPct = Math.round(f.health ?? 100);
          const satiety   = Math.max(0, 100 - Math.round(f.hunger ?? 0));
          const tooltipSide = pos.x > 65 ? 'left' : 'right';

          return (
            <div key={f.id}
              className={`fish-container ${isSelected ? 'selected' : ''} depth-layer-${depthLayer}${f.disease ? ' fish-diseased' : ''}`}
              style={{
                left: `${pos.x}%`,
                top:  `${pos.y}%`,
                opacity: layer.opacity,
                zIndex:  isSelected ? 30 : isHovered ? 25 : layer.z,
                filter: (depthFilter + glowStr).trim() || undefined,
                transform: `translate(-50%, -50%) rotate(${tiltAngle}deg)`,
              }}
              onMouseEnter={() => setHoveredFishId(f.id)}
              onMouseLeave={() => setHoveredFishId(null)}
              onClick={() => onSelectFish(f.id === selectedFishId ? null : f.id)}>
              <div className={`fish-anim-inner ${animClass}`}
                   data-species={f.species?.key || undefined}>
                <FishSprite fish={f} size={spriteSize} flipped={pos.flipped} selected={isSelected}/>
              </div>
              {f.stage !== 'adult' && <div className="stage-badge">{f.stage}</div>}
              {/* Floating status icons */}
              <div className="fish-status-icons">
                {f.disease && (
                  <span className="fish-status-icon fish-status-icon--sick" title="Sick">🦠</span>
                )}
                {!f.disease && f.hunger > 60 && (
                  <span className="fish-status-icon fish-status-icon--hungry" title="Hungry">🍤</span>
                )}
                {listedFishIds.includes(f.id) && (
                  <span className="fish-status-icon fish-status-icon--listed" title="Listed for sale">💰</span>
                )}
              </div>

              {/* Hover tooltip */}
              {isHovered && (
                <div className={`fish-tooltip fish-tooltip--${tooltipSide}`}>
                  <div className="fish-tooltip-name">{f.species?.name || 'Unknown'}</div>
                  <div className="fish-tooltip-row">
                    <span>❤</span>
                    <div className="fish-tooltip-bar">
                      <div className="fish-tooltip-fill" style={{
                        width: `${healthPct}%`,
                        background: healthPct > 60 ? '#3ddba0' : healthPct > 30 ? '#f5c542' : '#ff5566',
                        color: healthPct < 30 ? '#ff5566' : 'transparent',
                        boxShadow: healthPct < 30 ? '0 0 6px currentColor' : 'none',
                        animation: healthPct < 30 ? 'bar-critical-pulse 1.1s ease-in-out infinite' : 'none',
                      }}/>
                    </div>
                    <span className="fish-tooltip-val">{healthPct}%</span>
                  </div>
                  <div className="fish-tooltip-row">
                    <span>🍤</span>
                    <div className="fish-tooltip-bar">
                      <div className="fish-tooltip-fill" style={{
                        width: `${satiety}%`,
                        background: satiety > 60 ? '#5db8e8' : satiety > 30 ? '#f5a742' : '#ff6055',
                        color: satiety < 20 ? '#ff6055' : 'transparent',
                        boxShadow: satiety < 20 ? '0 0 6px currentColor' : 'none',
                        animation: satiety < 20 ? 'bar-critical-pulse 1.1s ease-in-out infinite' : 'none',
                      }}/>
                    </div>
                    <span className="fish-tooltip-val">{satiety}%</span>
                  </div>
                  {f.disease && <div className="fish-tooltip-disease">🦠 {f.disease}</div>}
                </div>
              )}
            </div>
          );
        })}

        {fish.length === 0 && (
          <div className="empty-tank">
            <p>Your tank is empty.</p>
            <p>Breed some fish to get started!</p>
          </div>
        )}

        {wq < 40 && (
          <div className="dirty-water" style={{ opacity: (40 - wq) / 40 * 0.45 }}/>
        )}

        {/* Step 4: Glass reflections */}
        <div className="tank-glass-left"/>
        <div className="tank-glass-right"/>
        <div className="tank-glass-top"/>
        <div className="tank-glass-bottom-fade"/>
      </div>
    </div>
  );
}
